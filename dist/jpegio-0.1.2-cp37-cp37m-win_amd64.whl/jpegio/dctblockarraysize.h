# pragma once

#include "jmorecfg.h"

struct DctBlockArraySize
{
    JDIMENSION nrows;
    JDIMENSION ncols;
};